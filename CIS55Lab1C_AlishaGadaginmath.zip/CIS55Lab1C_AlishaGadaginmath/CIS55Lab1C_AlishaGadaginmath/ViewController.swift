//
//  ViewController.swift
//  CIS55Lab1C_AlishaGadaginmath
//
//  Created by admin on 5/1/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var startingPay: UITextField!
    @IBOutlet var numDays: UITextField!
    @IBOutlet var outputField: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        startingPay.layer.cornerRadius = 10.0
        startingPay.layer.masksToBounds = true
        startingPay.layer.borderWidth = 2.0
        startingPay.layer.borderColor = UIColor.orange.cgColor
        
        numDays.layer.cornerRadius = 10.0
        numDays.layer.masksToBounds = true
        numDays.layer.borderWidth = 2.0
        numDays.layer.borderColor = UIColor.orange.cgColor
        
        outputField.layer.cornerRadius = 10.0
        outputField.layer.masksToBounds = true
        outputField.layer.borderWidth = 2.0
        outputField.layer.borderColor = UIColor.orange.cgColor
        
        clearInputField()
        printOutput("Please enter your starting pay on day 1 ... \n")
        printOutput("Please enter the number of days to calculate the pay for ... \n")
        printOutput("\n")
    }

    @IBAction func calcPay(_ sender: Any) {
        var countDays = 0
        var dailyPay: [Double] = [], totalPay: [Double] = []
        var tpay: Double = 0
        
        if (startingPay.text == "") && (numDays.text == "") {
            outputField.text = ""
            printOutput("Please enter your starting pay on day 1 ... \n")
            printOutput("Please enter the number of days to calculate the pay for ... \n")
            printOutput("\n")
        }
        else {
            let numDaysInt = Int(numDays.text!) ?? 0
            let startingPayDbl = Double(startingPay.text!) ?? 0.0
            var dpay = startingPayDbl
            while countDays < numDaysInt {
                dailyPay.append(dpay)
                tpay += dpay
                totalPay.append(tpay)
                printOutput(String(format: "On day %@, daily pay earned was $%.2f and total pay earned was $%.2f", String(countDays+1), dailyPay[countDays], totalPay[countDays]))
                printOutput("\n")
                dpay *= 2
                countDays += 1
            }
            clearInputField()
            printOutput("\n")
            printOutput("To Clear above text, click Calculate button again ... \n")
        }
    }
    
    func printOutput(_ printText: String) {
        outputField.text = outputField.text! + printText
        
    }
    
    func clearInputField() {
        startingPay.text = ""
        numDays.text = ""
    }
    
}

