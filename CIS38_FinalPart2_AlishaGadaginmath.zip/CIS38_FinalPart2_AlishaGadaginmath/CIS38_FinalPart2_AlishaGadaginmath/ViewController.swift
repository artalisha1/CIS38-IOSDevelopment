//
//  ViewController.swift
//  CIS38_FinalPart2_AlishaGadaginmath
//
//  Created by admin on 6/28/23.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    
    @IBOutlet var itemFrom: UILabel!
    @IBOutlet var itemTo: UILabel!
    @IBOutlet var itemDateTime: UILabel!
    @IBOutlet var myMap: MKMapView!
    @IBOutlet var directions: UITextView!
    @IBOutlet var totalMiles: UILabel!
    
    var myLocMgr = CLLocationManager()
    var myGeoCoder = CLGeocoder()
    var showPlacemark : CLPlacemark?
    
    var strFrom: String!
    var strTo: String!
    var strDateTime: String!
    
    var locationFrom : String = ""
    var locationTo : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.itemFrom.text = self.strFrom
        self.itemTo.text = self.strTo
        self.itemDateTime.text = self.strDateTime
        
        myLocMgr.delegate = self
        myLocMgr.requestWhenInUseAuthorization()
        myMap.delegate = self
        myMap.showsUserLocation = true
    }
    
    
    @IBAction func locateFrom(_ sender: Any) {
        locationFrom = self.itemFrom!.text!
        
        myGeoCoder.geocodeAddressString(locationFrom, completionHandler: {
            placemarks, error in
            
            if error != nil {
                print(error!)
                return
            }
            
            if placemarks != nil && placemarks!.count > 0 {
                let placemark = placemarks![0] as CLPlacemark
                self.showPlacemark = placemark
                
                let annotation = MKPointAnnotation()
                annotation.title = placemark.name
                annotation.coordinate = placemark.location!.coordinate
                self.myMap.addAnnotation(annotation)
                self.myMap.showAnnotations([annotation], animated: false)
            }
        })
    }
    
    
    @IBAction func locateTo(_ sender: Any) {
        let mySearchReq = MKLocalSearch.Request()
        mySearchReq.naturalLanguageQuery = self.itemTo.text!
        mySearchReq.region = self.myMap.region
        
        let localSearch = MKLocalSearch(request: mySearchReq)
        localSearch.start(completionHandler: {
            searchResponse, searchError in
            
            if searchError != nil {
                print(searchError!)
                return
            }
            
            let myMapItems = searchResponse!.mapItems as [MKMapItem]
            var annotations : [MKAnnotation] = []
            if myMapItems.count > 0 {
                for item in myMapItems {
                    let annotation = MKPointAnnotation()
                    annotation.coordinate = (item.placemark.location?.coordinate)!
                    annotation.title = item.name
                    annotations.append(annotation)
                }
            }
            self.myMap.showAnnotations(annotations, animated: true)
        })
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.blue
        renderer.lineWidth = 2.0
        return renderer
    }
    
    
    @IBAction func getRoute(_ sender: Any) {
        let dirReq = MKDirections.Request()
        let transType = MKDirectionsTransportType.automobile
        var myRoute : MKRoute?
        var showRoute = self.directions.text! + "\n"
        
        dirReq.source = MKMapItem.forCurrentLocation()
        dirReq.destination = MKMapItem(placemark: MKPlacemark(placemark: showPlacemark!))
        dirReq.transportType = transType
        
        let myDirections = MKDirections(request: dirReq) as MKDirections
        myDirections.calculate(completionHandler: {
            routeResponse, routeError in
            
            if routeError != nil {
                print(routeError!)
                return
            }
            
            myRoute = routeResponse?.routes[0] as MKRoute?
            
            self.myMap.removeOverlays(self.myMap.overlays)
            self.myMap.addOverlay((myRoute?.polyline)!, level: MKOverlayLevel.aboveRoads)
            
            let rect = myRoute?.polyline.boundingMapRect
            self.myMap.setRegion(MKCoordinateRegion(rect!), animated: true)
            
            if let steps = myRoute?.steps as [MKRoute.Step]? {
                for step in steps {
                    showRoute = showRoute + step.instructions + "\n"
                }
                self.directions.text = showRoute
            }
        })
    }
}

