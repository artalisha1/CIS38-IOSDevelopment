//
//  MyTableViewCell.swift
//  CIS38_FinalPart2_AlishaGadaginmath
//
//  Created by admin on 6/28/23.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    
    @IBOutlet var itemFrom: UILabel!
    @IBOutlet var itemTo: UILabel!
    @IBOutlet var itemDateTime: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
