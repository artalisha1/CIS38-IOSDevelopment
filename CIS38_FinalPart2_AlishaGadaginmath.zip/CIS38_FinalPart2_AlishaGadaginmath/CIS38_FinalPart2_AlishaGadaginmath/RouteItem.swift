//
//  RouteItem.swift
//  CIS38_FinalPart2_AlishaGadaginmath
//
//  Created by admin on 6/28/23.
//

import UIKit

class RouteItem: NSObject {
    var from = ""
    var to = ""
    var datetime = ""
    
    init(_ iFrom: String, _ iTo: String, _ iDateTime: String) {
        from = iFrom
        to = iTo
        datetime = iDateTime
    }
}
