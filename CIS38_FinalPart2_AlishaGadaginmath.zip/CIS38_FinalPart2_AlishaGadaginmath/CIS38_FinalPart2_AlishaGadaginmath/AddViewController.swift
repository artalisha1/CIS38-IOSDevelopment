//
//  AddViewController.swift
//  CIS38_FinalPart2_AlishaGadaginmath
//
//  Created by admin on 6/28/23.
//

import UIKit
import CoreData

class AddViewController: UIViewController {

    
    @IBOutlet var addFrom: UITextField!
    @IBOutlet var addTo: UITextField!
    @IBOutlet var addDateTime: UIDatePicker!
    
    var NewRoute : RouteItemMO!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func clickedCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    

    @IBAction func clickedSave(_ sender: Any) {
        if let myAppDelegate = (UIApplication.shared.delegate as? AppDelegate) {
            NewRoute = RouteItemMO(context: myAppDelegate.persistentContainer.viewContext)
            
            NewRoute.from = addFrom.text!
            NewRoute.to = addTo.text!
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
            let selectedDateTime = addDateTime.date
            let addDateTimeStr = dateFormatter.string(from: selectedDateTime)
            
            NewRoute.datetime = addDateTimeStr
            
            myAppDelegate.saveContext()
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
