import UIKit
var dailyPay: [Double] = [], totalPay: [Double] = []
var numDays: Int = 30
var i = 0, dpay = 0.01, tpay: Double = 0
print("Day #\t\tDay's pay\t\t\t\tTotal Pay")
while i < numDays {
    dailyPay.append(dpay)
    tpay += dpay
    totalPay.append(tpay)
    var dDollars = Int(dailyPay[i] * 100) / 100, dCents = Int(dailyPay[i] * 100) % 100
    var tDollars = Int(totalPay[i] * 100) / 100, tCents = Int(totalPay[i] * 100) % 100
    print(String(format:"%@\t\t%@\t\t%@", "\(i+1)", "\(dDollars) dollars \(dCents) cents", "\(tDollars) dollars \(tCents) cents"))
    dpay *= 2
    i += 1
}
