//
//  MyTableViewController.swift
//  CIS38Lab2_AlishaGadaginmath
//
//  Created by admin on 5/15/23.
//

import UIKit

class MyTableViewController: UITableViewController {

    var stateNames = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri"]

    var stateAbb = ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO"]
    
    var capital = ["Montgomery", "Juneau", "Phoenix", "Little Rock", "Sacramento", "Denver", "Hartford", "Dover", "Tallahassee", "Atlanta", "Honolulu", "Boise", "Springfield", "Indianapolis", "Des Moines", "Topeka", "Frankfort", "Baton Rouge", "Augusta", "Annapolis", "Boston", "Lansing", "Saint Paul", "Jackson", "Jefferson City"]
    
    var largestCity = ["Huntsville", "Anchorage", "Phoenix", "Little Rock", "Los Angeles", "Denver", "Bridgeport", "Wilmington", "Jacksonville", "Atlanta", "Honolulu", "Boise", "Chicago", "Indianapolis", "Des Moines", "Wichita", "Louisville", "New Orleans", "Portland", "Baltimore", "Boston", "Detroit", "Minneapolis", "Jackson", "Kansas City"]
    
    var population = ["5,039,877", "736,081", "7,151,502", "3,013,756", "39,185,605", "5,839,926", "3,605,944", "1,018,396", "22,244,823", "10,711,908", "1,455,271", "1,839,106", "12,812,508", "6,785,528", "3,190,369", "2,940,865", "4,509,342", "4,657,757", "1,362,359", "6,177,224", "6,981,974", "10,077,331", "5,717,184", "2,963,914", "6,160,281"]
    
    var area = ["52,419", "663,268", "113,990", "53,179", "163,696", "104,094", "5,018", "2,489", "65,758", "59,425", "10,931", "83,569", "57,915", "36,418", "55,857", "82,278", "40,408", "52,069", "35,385", "12,407", "10,565", "99,716", "86,935", "48,430", "69,715"]
    
    var stateImages = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri"]
    
    var stateSeals = ["AlabamaSeal", "AlaskaSeal", "ArizonaSeal", "ArkansasSeal", "CaliforniaSeal", "ColoradoSeal", "ConnecticutSeal", "DelawareSeal", "FloridaSeal", "GeorgiaSeal", "HawaiiSeal", "IdahoSeal", "IllinoisSeal", "IndianaSeal", "IowaSeal", "KansasSeal", "KentuckySeal", "LouisianaSeal", "MaineSeal", "MarylandSeal", "MassachusettsSeal", "MichiganSeal", "MinnesotaSeal", "MississippiSeal", "MissouriSeal"]
    
    var stateInfos: [String] = []
    var stateTitles: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return stateNames.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "StateCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! MyTableViewCell
        
        cell.cellText?.text = stateNames[indexPath.row]
        cell.cellImage?.image = UIImage(named: stateImages[indexPath.row])
            
        cell.alpha = 0
//        UIView.animate(withDuration: 10, animations: {cell.alpha = 1})
        
        var rotationTransform: CATransform3D = CATransform3DIdentity
        rotationTransform = CATransform3DTranslate(rotationTransform, -250, -250, 0)
        cell.cellImage?.layer.transform = rotationTransform
        UIView.animate(withDuration: 10, animations: {
            cell.cellImage?.layer.transform = CATransform3DIdentity
            cell.alpha = 1
        })

        return cell
    }
    
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//
//        if self.tableView.cellForRow(at: indexPath)?.accessoryType == UITableViewCell.AccessoryType.none {
//            self.tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
//        }
//        else {
//            self.tableView.cellForRow(at: indexPath)?.accessoryType = .none
//        }
//    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            stateNames.remove(at: indexPath.row)
            stateImages.remove(at: indexPath.row)
            
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ShowInfo" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let detailVC = segue.destination as! ViewController
                loadStateInfo()
                detailVC.strName = stateTitles[indexPath.row]
                detailVC.strInfo = stateInfos[indexPath.row]
                detailVC.imgFlag = UIImage(named: stateImages[indexPath.row])
                detailVC.imgSeal = UIImage(named: stateSeals[indexPath.row])
            }
        }
    }
    
    func loadStateInfo() {
        var countStates = 0
        while countStates < stateNames.count {
            stateInfos.append(String(format: "Capital City: %@\nLargest City: %@\nPopulation: %@\nArea: %@ sq. miles\n", capital[countStates], largestCity[countStates], population[countStates], area[countStates]))
            stateTitles.append(String(format: "%@ (%@)", stateNames[countStates], stateAbb[countStates]))
            countStates += 1
        }
    }

}
