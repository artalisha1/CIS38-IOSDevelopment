//
//  AddViewController.swift
//  CIS38Lab2_AlishaGadaginmath
//
//  Created by admin on 6/6/23.
//

import UIKit
import CoreData

class AddViewController: UIViewController {

    @IBOutlet var addName: UITextField!
    @IBOutlet var addFlag: UITextField!
    @IBOutlet var addTitle: UITextField!
    @IBOutlet var addSeal: UITextField!
    @IBOutlet var addInfo: UITextField!
    
    var newState: StateItemMO!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func clickedCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func clickedSave(_ sender: Any) {
        if let myAppDelegate = (UIApplication.shared.delegate as? AppDelegate) {
            newState = StateItemMO(context: myAppDelegate.persistentContainer.viewContext)
            
            newState.name = addName.text!
            newState.flag = addFlag.text!
            newState.title = addTitle.text!
            newState.seal = addSeal.text!
            newState.info = addInfo.text!
            
            myAppDelegate.saveContext()
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
