//
//  MyTableViewCell.swift
//  CIS38Lab2_AlishaGadaginmath
//
//  Created by admin on 5/15/23.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    
    
    @IBOutlet var cellImage: UIImageView!
    @IBOutlet var cellText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
