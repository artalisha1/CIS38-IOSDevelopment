//
//  MyTableViewController.swift
//  CIS38Lab2_AlishaGadaginmath
//
//  Created by admin on 5/15/23.
//

import UIKit
import CoreData

class MyTableViewController: UITableViewController, NSFetchedResultsControllerDelegate, UISearchResultsUpdating {
    
    
    var myStateItem : [StateItemMO] = []
    
    var fetchedResultsController : NSFetchedResultsController<StateItemMO>!
    
    var searchController : UISearchController!
    var searchResults : [StateItemMO] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.searchController = UISearchController(searchResultsController: nil)
        self.searchController.searchBar.sizeToFit()
        self.searchController.hidesNavigationBarDuringPresentation = false
        self.searchController.searchResultsUpdater = self
//        self.searchController.dimsBackgroundDuringPresentation = false
        self.tableView.tableHeaderView = self.searchController.searchBar
        
        let fetchRequest : NSFetchRequest<StateItemMO> = StateItemMO.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate) {
            let context = appDelegate.persistentContainer.viewContext
            fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
            fetchedResultsController.delegate = self
            
            do {
                try fetchedResultsController.performFetch()
                if let fetchedObjects = fetchedResultsController.fetchedObjects {
                    myStateItem = fetchedObjects
                }
            } catch {
                print (error)
            }
            
            if myStateItem.count == 0 {
                let seedStateItems = [StateItem("Alabama", "Alabama", "Alabama (AL)", "AlabamaSeal", "Capital City: Montgomery \nLargest City: Huntsville \nPopulation: 5,039,877 \nArea: 52,419 sq. miles\n"),
                  StateItem("Alaska", "Alaska", "Alaska (AK)", "AlaskaSeal", "Capital City: Juneau \nLargest City: Anchorage \nPopulation: 736,081 \nArea: 663,268 sq. miles\n"),
                  StateItem("Arizona", "Arizona", "Arizona (AZ)", "ArizonaSeal", "Capital City: Phoenix \nLargest City: Phoenix \nPopulation: 7,151,502 \nArea: 113,990 sq. miles\n"),
                  StateItem("Arkansas", "Arkansas", "Arkansas (AR)", "ArkansasSeal", "Capital City: Little Rock\nLargest City: Little Rock \nPopulation: 3,013,756 \nArea: 53,179 sq. miles\n"),
                  StateItem("California", "California", "California (CA)", "CaliforniaSeal", "Capital City: Sacramento \nLargest City: Los Angeles \nPopulation: 39,185,605 \nArea: 163,696 sq. miles\n"),
                  StateItem("Colorado", "Colorado", "Colorado (CO)", "ColoradoSeal", "Capital City: Denver \nLargest City: Denver \nPopulation: 5,839,926 \nArea: 104,094 sq. miles\n"),
                  StateItem("Connecticut", "Connecticut", "Connecticut (CT)", "ConnecticutSeal", "Capital City: Hartford \nLargest City: Bridgeport \nPopulation: 3,605,944 \nArea: 5,018 sq. miles\n"),
                  StateItem("Delaware", "Delaware", "Delaware (DE)", "DelawareSeal", "Capital City: Dover \nLargest City: Wilmington \nPopulation: 1,018,396 \nArea: 2,489 sq. miles\n"),
                  StateItem("Florida", "Florida", "Florida (FL)", "FloridaSeal", "Capital City: Tallahassee \nLargest City: Jacksonville \nPopulation: 22,244,823 \nArea: 65,758 sq. miles\n"),
                  StateItem("Georgia", "Georgia", "Georgia (GA)", "GeorgiaSeal", "Capital City: Atlanta \nLargest City: Atlanta \nPopulation: 10,711,908 \nArea: 59,425 sq. miles\n"),
                  StateItem("Hawaii", "Hawaii", "Hawaii (HI)", "HawaiiSeal", "Capital City: Honolulu \nLargest City: Honolulu \nPopulation: 1,455,271 \nArea: 10,931 sq. miles\n"),
                  StateItem("Idaho", "Idaho", "Idaho (ID)", "IdahoSeal", "Capital City: Boise \nLargest City: Boise \nPopulation: 1,839,106 \nArea: 83,569 sq. miles\n"),
                  StateItem("Illinois", "Illinois", "Illinois (IL)", "IllinoisSeal", "Capital City: Springfield \nLargest City: Chicago \nPopulation: 12,812,508 \nArea: 57,915 sq. miles\n"),
                  StateItem("Indiana", "Indiana", "Indiana (IN)", "Seal", "Capital City: Indianapolis \nLargest City: Indianapolis \nPopulation: 6,785,528 \nArea: 36,418 sq. miles\n"),
                  StateItem("Iowa", "Iowa", "Iowa (IA)", "IowaSeal", "Capital City: Des Moines \nLargest City: Des Moines \nPopulation: 3,190,369 \nArea: 55,857 sq. miles\n"),
                  StateItem("Kansas", "Kansas", "Kansas (KS)", "KansasSeal", "Capital City: Topeka \nLargest City: Wichita \nPopulation: 2,940,865 \nArea: 82,278 sq. miles\n"),
                  StateItem("Kentucky", "Kentucky", "Kentucky (KY)", "KentuckySeal", "Capital City: Frankfort \nLargest City: Louisville \nPopulation: 4,509,342 \nArea: 40,408 sq. miles\n"),
                  StateItem("Louisiana", "Louisiana", "Louisiana (LA)", "LouisianaSeal", "Capital City: Baton Rouge \nLargest City: New Orleans \nPopulation: 4,657,757 \nArea: 52,069 sq. miles\n"),
                  StateItem("Maine", "Maine", "Maine (ME)", "MaineSeal", "Capital City: Augusta \nLargest City: Portland \nPopulation: 1,362,359 \nArea: 35,385 sq. miles\n"),
                  StateItem("Maryland", "Maryland", "Maryland (MD)", "MarylandSeal", "Capital City: Annapolis \nLargest City: Baltimore \nPopulation: 6,177,224 \nArea: 12,407 sq. miles\n"),
                  StateItem("Massachusetts", "Massachusetts", "Massachusetts (MA)", "MassachusettsSeal", "Capital City: Boston \nLargest City: Boston \nPopulation: 6,981,974 \nArea: 10,565 sq. miles\n"),
                  StateItem("Michigan", "Michigan", "Michigan (MI)", "MichiganSeal", "Capital City: Lansing \nLargest City: Detroit \nPopulation: 10,077,331 \nArea: 99,716 sq. miles\n"),
                  StateItem("Minnesota", "Minnesota", "Minnesota (MN)", "MinnesotaSeal", "Capital City: Saint Paul \nLargest City: Minneapolis \nPopulation: 5,717,184 \nArea: 86,935 sq. miles\n"),
                  StateItem("Mississippi", "Mississippi", "Mississippi (MS)", "MississippiSeal", "Capital City: Jackson \nLargest City: Jackson \nPopulation: 2,963,914 \nArea: 48,430 sq. miles\n"),
                  StateItem("Missouri", "Missouri", "Missouri (MO)", "MissouriSeal", "Capital City: Jefferson City \nLargest City: Kansas City \nPopulation: 6,160,281 \nArea: 69,715 sq. miles\n")]
                
                for seedItem in seedStateItems {
                    let seedState = StateItemMO(context: context)
                    seedState.name = seedItem.name
                    seedState.flag = seedItem.flag
                    seedState.title = seedItem.title
                    seedState.seal = seedItem.seal
                    seedState.info = seedItem.info
                    
                    appDelegate.saveContext()
                }
            }
        }
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    private func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newindexPath: IndexPath?) {
        switch type {
        case .insert:
            if let insertIndexPath = newindexPath {
                tableView.insertRows(at: [insertIndexPath], with: .fade)
            }
            
        case .delete:
            if let deleteIndexPath = indexPath {
                tableView.deleteRows(at: [deleteIndexPath], with: .fade)
            }
            
        case .update:
            if let changeIndexPath = indexPath {
                tableView.reloadRows(at: [changeIndexPath], with: .fade)
            }
            
        default:
            tableView.reloadData()
        }
        
        if let fetchedObjects = controller.fetchedObjects {
            myStateItem = fetchedObjects as! [StateItemMO]
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if searchController.isActive {
            return searchResults.count
        }
        else {
            return myStateItem.count
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "StateCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! MyTableViewCell
        
        var cellItem : StateItemMO
        if searchController.isActive {
            cellItem = searchResults[indexPath.row]
        }
        else {
            cellItem = myStateItem[indexPath.row]
        }
        
        cell.cellText?.text = cellItem.name
        cell.cellImage?.image = UIImage(named: cellItem.flag ?? "Alabama")
        
//        cell.alpha = 0
//        //        UIView.animate(withDuration: 10, animations: {cell.alpha = 1})
//
//        var rotationTransform: CATransform3D = CATransform3DIdentity
//        rotationTransform = CATransform3DTranslate(rotationTransform, -250, -250, 0)
//        cell.cellImage?.layer.transform = rotationTransform
//        UIView.animate(withDuration: 10, animations: {
//            cell.cellImage?.layer.transform = CATransform3DIdentity
//            cell.alpha = 1
//        })
        
        return cell
    }
    
//        override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//            if !searchController.isActive {
//                if self.tableView.cellForRow(at: indexPath)?.accessoryType == UITableViewCell.AccessoryType.none {
//                    self.tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
//                }
//                else {
//                    self.tableView.cellForRow(at: indexPath)?.accessoryType = .none
//                }
//            }
//        }
    
    
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
         if searchController.isActive {
             return false
         }
         else {
             return true
         }
     }
    
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if let appDelegate = (UIApplication.shared.delegate as? AppDelegate) {
                let context = appDelegate.persistentContainer.viewContext
                let deleteItem = self.fetchedResultsController.object(at: indexPath)
                context.delete(deleteItem)
                appDelegate.saveContext()
                //            myStateItem.remove(at: indexPath.row)
                //            stateNames.remove(at: indexPath.row)
                //            stateImages.remove(at: indexPath.row)
                
                // Delete the row from the data source
                tableView.deleteRows(at: [indexPath], with: .fade)
            } else if editingStyle == .insert {
                // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
            }
        }
    }
        
        /*
         // Override to support rearranging the table view.
         override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
         
         }
         */
        
        /*
         // Override to support conditional rearranging of the table view.
         override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
         // Return false if you do not want the item to be re-orderable.
         return true
         }
         */
        
        // MARK: - Navigation
        
        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
            if segue.identifier == "ShowInfo" {
                if let indexPath = self.tableView.indexPathForSelectedRow {
                    let detailVC = segue.destination as! ViewController
                    var cellItem : StateItemMO
                    if searchController.isActive {
                        cellItem = searchResults[indexPath.row]
                    }
                    else {
                        cellItem = myStateItem[indexPath.row]
                    }
                    //                loadStateInfo()
                    detailVC.strName = cellItem.title
                    detailVC.strInfo = cellItem.info
                    detailVC.imgFlag = UIImage(named: cellItem.flag ?? "Alabama")
                    detailVC.imgSeal = UIImage(named: cellItem.seal ?? "AlabamaSeal")
                }
            }
        }
        
        func updateSearchResults(for searchController: UISearchController) {
            if let textToSearch = searchController.searchBar.text {
                filterContentForSearchText(searchText: textToSearch)
                tableView.reloadData()
            }
        }
        
        func filterContentForSearchText(searchText: String) {
            searchResults = myStateItem.filter({ (searchItem: StateItemMO) -> Bool in
                let nameMatch = searchItem.name?.range(of: searchText, options: String.CompareOptions.caseInsensitive)
                return nameMatch != nil
        })
    }
}
