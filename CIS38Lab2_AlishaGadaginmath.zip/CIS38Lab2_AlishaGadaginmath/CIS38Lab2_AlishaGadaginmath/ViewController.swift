//
//  ViewController.swift
//  CIS38Lab2_AlishaGadaginmath
//
//  Created by admin on 5/15/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var stateName: UILabel!
    @IBOutlet var stateFlag: UIImageView!
    @IBOutlet var stateInfo: UILabel!
    @IBOutlet var stateSeal: UIImageView!
    
    
    var strName: String!
    var strInfo: String!
    var imgFlag: UIImage!
    var imgSeal: UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.stateName.text = self.strName
        self.stateInfo.text = self.strInfo
        self.stateFlag.image = self.imgFlag
        self.stateSeal.image = self.imgSeal
        
        self.stateName.alpha = 0
        var rotationTransform: CATransform3D = CATransform3DIdentity
                rotationTransform = CATransform3DTranslate(rotationTransform, -250, -250, 0)
                self.stateFlag.layer.transform = rotationTransform
                UIView.animate(withDuration: 5, animations: {
                    self.stateFlag.layer.transform = CATransform3DIdentity
                    self.stateName.alpha = 1
                })
    }

    
}

