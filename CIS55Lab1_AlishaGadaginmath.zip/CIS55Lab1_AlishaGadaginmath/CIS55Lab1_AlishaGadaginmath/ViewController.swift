//
//  ViewController.swift
//  CIS55Lab1_AlishaGadaginmath
//
//  Created by admin on 4/17/23.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet var field: UITextField!
    @IBOutlet var buttonLabel: UIButton!
    @IBOutlet var label: UILabel!
    
    var name = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view
    }
    
    @IBAction func buttonClick(_ sender: Any) {
        name = field.text!
        label.text = name
    }
}

