//
//  MapViewController.swift
//  CIS38Lab2_AlishaGadaginmath
//
//  Created by admin on 6/14/23.
//

import UIKit
import CoreLocation
import MapKit

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet var address: UITextField!
    @IBOutlet var directions: UITextView!
    @IBOutlet var nearby: UITextField!
    @IBOutlet var btnAddress: UIButton!
    @IBOutlet var btnDirections: UIButton!
    @IBOutlet var btnNearby: UIButton!
    @IBOutlet var myMap: MKMapView!
    
    var myLocMgr = CLLocationManager()
    var myGeoCoder = CLGeocoder()
    var showPlacemark : CLPlacemark?
    
    var findAddress : String = ""
    var capitol : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        myLocMgr.delegate = self
        myLocMgr.requestWhenInUseAuthorization()
        myMap.delegate = self
        myMap.showsUserLocation = true
        //view.backgroundColor = .gray
        
        self.findAddress = self.capitol
        
        myGeoCoder.geocodeAddressString(findAddress, completionHandler: {
            placemarks, error in
            
            if error != nil {
                print(error!)
                return
            }
            
            if placemarks != nil && placemarks!.count > 0 {
                let placemark = placemarks![0] as CLPlacemark
                self.showPlacemark = placemark
                
                let annotation = MKPointAnnotation()
                annotation.title = placemark.name
                annotation.coordinate = placemark.location!.coordinate
                self.myMap.addAnnotation(annotation)
                self.myMap.showAnnotations([annotation], animated: false)
            }
        })
    }
    

    @IBAction func locateAddr(_ sender: Any) {
        self.findAddress = self.address!.text!
        
        myGeoCoder.geocodeAddressString(findAddress, completionHandler: {
            placemarks, error in
            
            if error != nil {
                print(error!)
                return
            }
            
            if placemarks != nil && placemarks!.count > 0 {
                let placemark = placemarks![0] as CLPlacemark
                self.showPlacemark = placemark
                
                let annotation = MKPointAnnotation()
                annotation.title = placemark.name
                annotation.coordinate = placemark.location!.coordinate
                self.myMap.addAnnotation(annotation)
                self.myMap.showAnnotations([annotation], animated: false)
            }
        })
    }
    
    
    @IBAction func getRoute(_ sender: Any) {
        let dirReq = MKDirections.Request()
        let transType = MKDirectionsTransportType.automobile
        var myRoute : MKRoute?
        var showRoute = self.directions.text! + "\n"
        
        dirReq.source = MKMapItem.forCurrentLocation()
        dirReq.destination = MKMapItem(placemark: MKPlacemark(placemark: showPlacemark!))
        dirReq.transportType = transType
        
        let myDirections = MKDirections(request: dirReq) as MKDirections
        myDirections.calculate(completionHandler: {
            routeResponse, routeError in
            
            if routeError != nil {
                print(routeError!)
                return
            }
            
            myRoute = routeResponse?.routes[0] as MKRoute?
            
            self.myMap.removeOverlays(self.myMap.overlays)
            self.myMap.addOverlay((myRoute?.polyline)!, level: MKOverlayLevel.aboveRoads)
            
            let rect = myRoute?.polyline.boundingMapRect
            self.myMap.setRegion(MKCoordinateRegion(rect!), animated: true)
            
            if let steps = myRoute?.steps as [MKRoute.Step]? {
                for step in steps {
                    showRoute = showRoute + step.instructions + "\n"
                }
                self.directions.text = showRoute
            }
        })
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.blue
        renderer.lineWidth = 2.0
        return renderer
    }
    
    @IBAction func findNearby(_ sender: Any) {
        let mySearchReq = MKLocalSearch.Request()
        mySearchReq.naturalLanguageQuery = self.nearby.text!
        mySearchReq.region = self.myMap.region
        
        let localSearch = MKLocalSearch(request: mySearchReq)
        localSearch.start(completionHandler: {
            searchResponse, searchError in
            
            if searchError != nil {
                print(searchError!)
                return
            }
            
            let myMapItems = searchResponse!.mapItems as [MKMapItem]
            var annotations : [MKAnnotation] = []
            if myMapItems.count > 0 {
                for item in myMapItems {
                    let annotation = MKPointAnnotation()
                    annotation.coordinate = (item.placemark.location?.coordinate)!
                    annotation.title = item.name
                    annotations.append(annotation)
                }
            }
            self.myMap.showAnnotations(annotations, animated: true)
        })
    }

}
