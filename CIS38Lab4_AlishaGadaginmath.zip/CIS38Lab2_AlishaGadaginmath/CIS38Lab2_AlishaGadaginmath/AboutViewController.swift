//
//  AboutViewController.swift
//  CIS38Lab2_AlishaGadaginmath
//
//  Created by admin on 5/15/23.
//

import UIKit

class AboutViewController: UIViewController {

    @IBOutlet var myName: UILabel!
    @IBOutlet var aboutMeInfo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        myName.text = "Alisha Gadaginmath"
        aboutMeInfo.text = "Hello, everyone! My name is Alisha Gadginmath and I am currently a senior in high school, almost off to college!! I enjoy meeting new people and creating exciting, yet challenging experiences for myself. Some of my interests include Indian Classical Dance, Field Hockey, and painting. I am passionate about Computer Science so I took this iOS Development class to learn how to create apps and understand the innerworkings of them as well. So far, I have been learning a lot and I am really glad I joined this class. Thanks for reading!"
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
