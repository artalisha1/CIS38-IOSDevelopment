//
//  StateItem.swift
//  CIS38Lab2_AlishaGadaginmath
//
//  Created by admin on 6/6/23.
//

import UIKit

class StateItem: NSObject {
    var name = ""
    var flag = ""
    var title = ""
    var seal = ""
    var info = ""
    
    init(_ iName: String, _ iFlag: String, _ iTitle: String, _ iSeal: String, _ iInfo: String) {
        name = iName
        flag = iFlag
        title = iTitle
        seal = iSeal
        info = iInfo
    }
}
